export const PORT = 4000;
export const SECRET_KEY = 'tu_secreto';