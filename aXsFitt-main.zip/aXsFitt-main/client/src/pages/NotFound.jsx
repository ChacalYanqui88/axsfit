import React from 'react'

const NotFound = () => {
  return (
    <div className='container-page'>
      <h1>NotFound</h1>
    </div>
  )
}

export default NotFound